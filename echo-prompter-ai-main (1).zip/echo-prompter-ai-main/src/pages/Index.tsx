import { Helmet } from "react-helmet";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import WhatWeDoSection from "@/components/WhatWeDoSection";
import ServicesSection from "@/components/ServicesSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import WhoItsForSection from "@/components/WhoItsForSection";
import WhyLocalFlowSection from "@/components/WhyLocalFlowSection";
import FAQSection from "@/components/FAQSection";
import BookDemoSection from "@/components/BookDemoSection";
import Footer from "@/components/Footer";
import AIChatWidget from "@/components/AIChatWidget";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>LocalFlow AI – Automate Calls, Reviews & Customer Conversations</title>
        <meta
          name="description"
          content="LocalFlow AI helps local businesses never miss calls, collect more 5-star reviews, and follow up with customers automatically — without hiring staff."
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="canonical" href="https://localflowai.com" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        <main>
          <HeroSection />
          <WhatWeDoSection />
          <ServicesSection />
          <HowItWorksSection />
          <WhoItsForSection />
          <WhyLocalFlowSection />
          <FAQSection />
          <BookDemoSection />
        </main>
        <Footer />
        <AIChatWidget />
      </div>
    </>
  );
};

export default Index;
