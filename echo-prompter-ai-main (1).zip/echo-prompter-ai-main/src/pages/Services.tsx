import { Helmet } from "react-helmet";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AIChatWidget from "@/components/AIChatWidget";
import { Button } from "@/components/ui/button";
import { Phone, Star, MessageSquare, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Services = () => {
  const navigate = useNavigate();

  const services = [
    {
      icon: Phone,
      title: "AI Voice Receptionist",
      description: "Your 24/7 virtual receptionist that never misses a call",
      features: [
        "Answers inbound calls 24/7",
        "Books appointments automatically",
        "Handles FAQs professionally",
        "Sends missed-call text messages",
        "Transfers urgent calls if needed",
      ],
      benefit: "Never miss a lead again.",
    },
    {
      icon: Star,
      title: "Review AI System",
      description: "Automate your reputation management",
      features: [
        "Automatically requests reviews via SMS",
        "Follows up with customers",
        "Responds to reviews using AI",
        "Improves Google Maps visibility",
      ],
      benefit: "More 5-star reviews, more trust.",
    },
    {
      icon: MessageSquare,
      title: "AI Employee (Chat & SMS)",
      description: "Your tireless digital team member",
      features: [
        "Website chat assistant",
        "SMS follow-ups",
        "Lead qualification",
        "Appointment scheduling",
      ],
      benefit: "Turn visitors into booked appointments automatically.",
    },
  ];

  return (
    <>
      <Helmet>
        <title>Our Services | LocalFlow AI</title>
        <meta
          name="description"
          content="Explore LocalFlow AI's services: AI Voice Receptionist, Review AI System, and AI Employee for chat and SMS automation."
        />
      </Helmet>

      <Header />

      <main className="min-h-screen bg-background pt-24">
        {/* Hero Section */}
        <section className="section-padding py-20">
          <div className="container-custom text-center">
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Our <span className="gradient-text">Services</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
              Powerful AI solutions designed specifically for local businesses. 
              Automate your customer communication and grow your business 24/7.
            </p>
          </div>
        </section>

        {/* Services Detail */}
        <section className="section-padding pb-20">
          <div className="container-custom">
            <div className="space-y-20">
              {services.map((service, index) => (
                <div
                  key={service.title}
                  className={`flex flex-col ${
                    index % 2 === 1 ? "lg:flex-row-reverse" : "lg:flex-row"
                  } gap-12 items-center`}
                >
                  {/* Icon & Title Side */}
                  <div className="flex-1 text-center lg:text-left">
                    <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-accent mb-6">
                      <service.icon className="w-10 h-10 text-primary-foreground" />
                    </div>
                    <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
                      {service.title}
                    </h2>
                    <p className="text-lg text-muted-foreground mb-6">
                      {service.description}
                    </p>
                    <div className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
                      <span className="text-primary font-semibold">{service.benefit}</span>
                    </div>
                  </div>

                  {/* Features Side */}
                  <div className="flex-1">
                    <div className="glass rounded-2xl p-8">
                      <h3 className="font-heading text-xl font-semibold text-foreground mb-6">
                        What's Included
                      </h3>
                      <ul className="space-y-4">
                        {service.features.map((feature) => (
                          <li key={feature} className="flex items-start gap-3">
                            <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                            <span className="text-muted-foreground">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button
                        variant="hero"
                        size="lg"
                        className="w-full mt-8"
                        onClick={() => navigate("/get-started")}
                      >
                        Get Started
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="section-padding py-20 bg-card/50">
          <div className="container-custom text-center">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
              Ready to Transform Your Business?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Book a free demo and discover how LocalFlow AI can help you automate 
              customer communication and grow your business.
            </p>
            <Button variant="hero" size="lg" asChild>
              <a href="#book-demo">Book Free Demo</a>
            </Button>
          </div>
        </section>
      </main>

      <Footer />
      <AIChatWidget />
    </>
  );
};

export default Services;
