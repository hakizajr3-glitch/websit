import { Helmet } from "react-helmet";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AIChatWidget from "@/components/AIChatWidget";
import { Button } from "@/components/ui/button";
import { Calendar, Search, Rocket, Zap, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const HowItWorks = () => {
  const navigate = useNavigate();

  const steps = [
    {
      number: "01",
      icon: Calendar,
      title: "Book a Free Demo",
      description:
        "Schedule a quick 15-minute call with our team. We'll learn about your business and show you exactly how our AI solutions can help you grow.",
    },
    {
      number: "02",
      icon: Search,
      title: "We Analyze Your Business",
      description:
        "Our team reviews your current processes, identifies opportunities for automation, and creates a customized plan tailored to your specific needs.",
    },
    {
      number: "03",
      icon: Rocket,
      title: "We Deploy Your AI Systems",
      description:
        "We handle all the technical setup. Your AI receptionist, review system, or chat assistant will be live and ready to work within days, not weeks.",
    },
    {
      number: "04",
      icon: Zap,
      title: "Your Business Runs Smarter 24/7",
      description:
        "Watch as your AI systems handle calls, collect reviews, and engage customers around the clock. Focus on what you do best while AI handles the rest.",
    },
  ];

  return (
    <>
      <Helmet>
        <title>How It Works | LocalFlow AI</title>
        <meta
          name="description"
          content="Learn how LocalFlow AI works: Book a demo, we analyze your business, deploy AI systems, and your business runs smarter 24/7."
        />
      </Helmet>

      <Header />

      <main className="min-h-screen bg-background pt-24">
        {/* Hero Section */}
        <section className="section-padding py-20">
          <div className="container-custom text-center">
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              How It <span className="gradient-text">Works</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
              Getting started with LocalFlow AI is simple. We handle all the technical 
              complexity so you can focus on running your business.
            </p>
          </div>
        </section>

        {/* Steps Section */}
        <section className="section-padding pb-20">
          <div className="container-custom">
            <div className="relative">
              {/* Connection Line */}
              <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-primary/20 -translate-x-1/2" />

              <div className="space-y-16 lg:space-y-24">
                {steps.map((step, index) => (
                  <div
                    key={step.number}
                    className={`flex flex-col ${
                      index % 2 === 1 ? "lg:flex-row-reverse" : "lg:flex-row"
                    } gap-8 lg:gap-16 items-center`}
                  >
                    {/* Content Side */}
                    <div className="flex-1 text-center lg:text-left">
                      <div className="glass rounded-2xl p-8 relative">
                        <span className="absolute -top-4 left-8 px-4 py-1 bg-gradient-to-r from-primary to-accent text-primary-foreground font-heading font-bold rounded-full text-sm">
                          Step {step.number}
                        </span>
                        <div className="pt-4">
                          <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-4">
                            {step.title}
                          </h2>
                          <p className="text-muted-foreground text-lg">
                            {step.description}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Icon Side */}
                    <div className="flex-shrink-0 order-first lg:order-none">
                      <div className="relative">
                        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow">
                          <step.icon className="w-10 h-10 text-primary-foreground" />
                        </div>
                        {index < steps.length - 1 && (
                          <ArrowRight className="hidden lg:hidden w-6 h-6 text-primary absolute -bottom-10 left-1/2 -translate-x-1/2 rotate-90" />
                        )}
                      </div>
                    </div>

                    {/* Empty space for alternating layout */}
                    <div className="flex-1 hidden lg:block" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="section-padding py-20 bg-card/50">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
                Why This Process Works
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                We've refined our process to make AI adoption seamless and stress-free.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  title: "No Technical Skills Required",
                  description: "We handle all the setup. You just tell us about your business.",
                },
                {
                  title: "Fast Implementation",
                  description: "Most systems are live within 3-7 business days.",
                },
                {
                  title: "Ongoing Support",
                  description: "We're here to help you get the most out of your AI systems.",
                },
              ].map((benefit) => (
                <div key={benefit.title} className="glass rounded-2xl p-6 text-center">
                  <h3 className="font-heading text-xl font-semibold text-foreground mb-3">
                    {benefit.title}
                  </h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="section-padding py-20">
          <div className="container-custom text-center">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Book your free demo today and see how easy it is to automate your business.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg" asChild>
                <a href="#book-demo">Book Free Demo</a>
              </Button>
              <Button variant="outline" size="lg" onClick={() => navigate("/services")}>
                View Services
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <AIChatWidget />
    </>
  );
};

export default HowItWorks;
