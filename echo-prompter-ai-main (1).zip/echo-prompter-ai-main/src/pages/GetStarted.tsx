import { Phone, Star, MessageSquare, CheckCircle, ArrowRight, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const GetStarted = () => {
  const services = [
    {
      id: "ai-voice-receptionist",
      icon: Phone,
      title: "AI Voice Receptionist",
      description: "Never miss a call again. Your AI receptionist handles everything professionally, 24/7.",
      features: [
        "Answers inbound calls 24/7",
        "Books appointments automatically",
        "Handles FAQs instantly",
        "Sends missed-call text messages",
        "Transfers urgent calls if needed",
      ],
      benefit: "Never miss a lead again.",
    },
    {
      id: "review-ai-system",
      icon: Star,
      title: "Review AI System",
      description: "Automate your reputation management and watch your 5-star reviews multiply.",
      features: [
        "Automatically requests reviews via SMS",
        "Follows up with customers",
        "Responds to reviews using AI",
        "Improves Google Maps visibility",
        "Tracks review performance",
      ],
      benefit: "More 5-star reviews, more trust.",
    },
    {
      id: "ai-employee",
      icon: MessageSquare,
      title: "AI Employee (Chat & SMS)",
      description: "Your tireless AI employee engages leads and books appointments around the clock.",
      features: [
        "Website chat assistant",
        "SMS follow-ups",
        "Lead qualification",
        "Appointment scheduling",
        "Multi-channel support",
      ],
      benefit: "Turn visitors into booked appointments automatically.",
    },
  ];

  const handleBookDemo = (serviceTitle: string) => {
    // Open Calendly with service context
    const calendlyUrl = `https://calendly.com?service=${encodeURIComponent(serviceTitle)}`;
    window.open(calendlyUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Background Effects */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,hsl(var(--primary)/0.15),transparent_50%)]" />
      <div className="fixed top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="fixed bottom-1/4 left-1/4 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />

      <div className="relative z-10">
        {/* Header */}
        <header className="glass border-b border-border">
          <div className="container-custom section-padding !py-4">
            <nav className="flex items-center justify-between">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <span className="text-primary-foreground font-heading font-bold text-xl">L</span>
                </div>
                <span className="font-heading font-bold text-xl text-foreground">
                  LocalFlow <span className="gradient-text">AI</span>
                </span>
              </Link>
              <Button variant="ghost" asChild>
                <Link to="/" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Home
                </Link>
              </Button>
            </nav>
          </div>
        </header>

        {/* Main Content */}
        <main className="container-custom section-padding pt-12">
          {/* Page Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              Get Started
            </span>
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Choose Your{" "}
              <span className="gradient-text">AI Solution</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              Select the service that best fits your business needs, then book a free demo 
              with our team to get started.
            </p>
          </div>

          {/* Service Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {services.map((service, index) => (
              <div
                key={index}
                className="group relative"
              >
                {/* Glow Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/10 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative glass rounded-3xl p-8 h-full flex flex-col hover:bg-card/80 transition-all duration-300 border border-border/50 hover:border-primary/30">
                  {/* Icon */}
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-8 h-8 text-primary-foreground" />
                  </div>

                  {/* Title */}
                  <h3 className="font-heading text-2xl font-bold text-foreground mb-3">
                    {service.title}
                  </h3>

                  {/* Description */}
                  <p className="text-muted-foreground mb-6">
                    {service.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-3 mb-8 flex-grow">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Benefit Badge */}
                  <div className="mb-6">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
                      <span className="w-2 h-2 rounded-full bg-primary" />
                      <span className="text-sm font-medium text-primary">{service.benefit}</span>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <Button 
                    variant="hero" 
                    size="lg" 
                    className="w-full group/btn"
                    onClick={() => handleBookDemo(service.title)}
                  >
                    Book Demo for {service.title.split(' ')[0]}
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="text-center mt-16">
            <p className="text-muted-foreground mb-4">
              Not sure which service is right for you?
            </p>
            <Button variant="hero-outline" size="xl" asChild>
              <a href="https://calendly.com" target="_blank" rel="noopener noreferrer">
                Book a General Consultation
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default GetStarted;
