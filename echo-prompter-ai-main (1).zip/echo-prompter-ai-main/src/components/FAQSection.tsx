import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQSection = () => {
  const faqs = [
    {
      question: "How long does setup take?",
      answer: "Most systems are live within 3–7 business days. We handle everything from configuration to testing, so you can focus on your business while we get your AI up and running.",
    },
    {
      question: "Do I need technical skills?",
      answer: "Absolutely not. Everything is handled for you by our expert team. We configure, train, and optimize your AI systems — you just need to tell us about your business.",
    },
    {
      question: "Can this work with my existing website?",
      answer: "Yes! Our AI chat widget and systems integrate seamlessly with any existing website. No redesign needed — we work with what you have.",
    },
    {
      question: "What if I have multiple locations?",
      answer: "LocalFlow AI is designed to scale. We can deploy AI systems across all your locations with customized settings for each one.",
    },
    {
      question: "Is there a contract?",
      answer: "We offer flexible month-to-month options. We're confident you'll love the results, but you're never locked in.",
    },
    {
      question: "How do I get pricing information?",
      answer: "Pricing is customized based on your business needs. Book a free demo and we'll provide a clear, transparent quote tailored to your requirements.",
    },
  ];

  return (
    <section id="faq" className="relative section-padding">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,hsl(var(--primary)/0.05),transparent_70%)]" />

      <div className="container-custom relative z-10">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              FAQ
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Got{" "}
              <span className="gradient-text">Questions?</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Here are answers to the most common questions about LocalFlow AI.
            </p>
          </div>

          {/* Accordion */}
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="glass rounded-2xl border-0 px-6 data-[state=open]:bg-card/80"
              >
                <AccordionTrigger className="text-left font-heading font-semibold text-foreground hover:no-underline py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
