import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, Video, Clock } from "lucide-react";

const BookDemoSection = () => {
  return (
    <section id="book-demo" className="relative section-padding overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/20 rounded-full blur-3xl opacity-50" />

      <div className="container-custom relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Content Card */}
          <div className="glass rounded-3xl p-8 lg:p-16 text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Free Demo Available</span>
            </div>

            {/* Headline */}
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Ready to{" "}
              <span className="gradient-text">Automate Your Business?</span>
            </h2>

            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Book a free demo and see exactly how LocalFlow AI can transform your 
              customer communication. No pressure, no obligation — just a friendly 
              conversation about your business.
            </p>

            {/* Features */}
            <div className="flex flex-wrap justify-center gap-6 mb-10">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Video className="w-5 h-5 text-primary" />
                <span className="text-sm">Zoom or Google Meet</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="w-5 h-5 text-primary" />
                <span className="text-sm">30 Minutes</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="w-5 h-5 text-primary" />
                <span className="text-sm">Flexible Scheduling</span>
              </div>
            </div>

            {/* CTA Button */}
            <Button variant="hero" size="xl" className="group" asChild>
              <a href="https://calendly.com" target="_blank" rel="noopener noreferrer">
                Book Your Free Demo
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </Button>

            <p className="text-sm text-muted-foreground mt-6">
              No credit card required. Cancel anytime.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookDemoSection;
