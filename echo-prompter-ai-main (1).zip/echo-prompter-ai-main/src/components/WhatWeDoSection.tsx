import { Zap, Clock, Heart, Sparkles } from "lucide-react";

const WhatWeDoSection = () => {
  const features = [
    {
      icon: Clock,
      title: "No Missed Calls",
      description: "Your AI receptionist answers every call, day or night, so you never lose a lead.",
    },
    {
      icon: Zap,
      title: "Faster Responses",
      description: "Instant SMS and chat responses keep customers engaged and ready to book.",
    },
    {
      icon: Heart,
      title: "Better Experience",
      description: "Professional, consistent communication that makes customers feel valued.",
    },
    {
      icon: Sparkles,
      title: "Zero Complexity",
      description: "We handle everything. You focus on what you do best — running your business.",
    },
  ];

  return (
    <section className="relative section-padding">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              What We Do
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 text-balance">
              AI-Powered Automation for{" "}
              <span className="gradient-text">Local Businesses</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              LocalFlow AI provides AI-powered receptionists, review automation, and AI employees 
              that work 24/7 to help your local business grow. We handle the communication so you 
              can focus on delivering great service.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-foreground mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-3xl" />
            <div className="relative glass rounded-3xl p-8 lg:p-12">
              <div className="space-y-6">
                {/* Simulated Chat Interface */}
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                    <span className="text-primary font-bold text-sm">AI</span>
                  </div>
                  <div className="glass rounded-2xl rounded-tl-sm p-4 max-w-xs">
                    <p className="text-sm text-foreground">
                      Hi! Thank you for calling. How can I help you today?
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 justify-end">
                  <div className="bg-primary rounded-2xl rounded-tr-sm p-4 max-w-xs">
                    <p className="text-sm text-primary-foreground">
                      I'd like to book an appointment for tomorrow.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                    <span className="text-primary font-bold text-sm">AI</span>
                  </div>
                  <div className="glass rounded-2xl rounded-tl-sm p-4 max-w-xs">
                    <p className="text-sm text-foreground">
                      Perfect! I have 2pm and 4pm available. Which works better for you?
                    </p>
                  </div>
                </div>

                {/* Typing Indicator */}
                <div className="flex items-center gap-1 ml-13 pl-13">
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatWeDoSection;
