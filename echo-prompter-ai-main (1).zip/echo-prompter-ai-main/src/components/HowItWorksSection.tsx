import { Calendar, Search, Rocket, Sparkles } from "lucide-react";

const HowItWorksSection = () => {
  const steps = [
    {
      icon: Calendar,
      step: "01",
      title: "Book a Free Demo",
      description: "Schedule a quick call with our team. We'll learn about your business and show you exactly how AI can help.",
    },
    {
      icon: Search,
      step: "02",
      title: "We Analyze Your Business",
      description: "Our experts review your current setup and design a custom AI solution tailored to your specific needs.",
    },
    {
      icon: Rocket,
      step: "03",
      title: "We Deploy Your AI Systems",
      description: "Sit back while we handle everything. Your AI receptionist, review system, and chat assistant go live.",
    },
    {
      icon: Sparkles,
      step: "04",
      title: "Your Business Runs Smarter 24/7",
      description: "Watch as your AI handles calls, collects reviews, and books appointments — even while you sleep.",
    },
  ];

  return (
    <section id="how-it-works" className="relative section-padding overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px]" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            How It Works
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            From Demo to{" "}
            <span className="gradient-text">Automation in Days</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Getting started is simple. No technical skills required — we handle everything for you.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div
                key={index}
                className="relative group"
              >
                {/* Step Number */}
                <div className="relative z-10 w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                  <step.icon className="w-10 h-10 text-primary-foreground" />
                  <span className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-card border-2 border-primary flex items-center justify-center text-sm font-bold text-primary">
                    {step.step}
                  </span>
                </div>

                {/* Content */}
                <div className="text-center">
                  <h3 className="font-heading text-xl font-bold text-foreground mb-3">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
