import { Target, Settings, Users, Clock, TrendingUp } from "lucide-react";

const WhyLocalFlowSection = () => {
  const reasons = [
    {
      icon: Target,
      title: "Built for Local Businesses",
      description: "Unlike generic solutions, we specialize in helping local service businesses thrive.",
    },
    {
      icon: Settings,
      title: "Done-For-You Setup",
      description: "No DIY headaches. We configure everything and train your AI to work perfectly for your business.",
    },
    {
      icon: Users,
      title: "No Hiring Required",
      description: "Get the power of a full-time receptionist without the payroll, training, or management.",
    },
    {
      icon: Clock,
      title: "AI Works 24/7",
      description: "Your AI never sleeps, takes breaks, or calls in sick. It's always ready to help customers.",
    },
    {
      icon: TrendingUp,
      title: "Scales With Your Business",
      description: "Handle more calls and customers without adding overhead as your business grows.",
    },
  ];

  return (
    <section className="relative section-padding">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            Why LocalFlow AI
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            The Smart Choice for{" "}
            <span className="gradient-text">Growing Businesses</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            We're not just another AI tool. We're your partner in building a more 
            efficient, profitable business.
          </p>
        </div>

        {/* Reasons Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className={`glass rounded-2xl p-6 hover:bg-card/80 transition-all duration-300 group ${
                index === 4 ? 'lg:col-start-2' : ''
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                  <reason.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-foreground mb-2">
                    {reason.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {reason.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyLocalFlowSection;
