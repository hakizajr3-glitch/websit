import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const navLinks = [
    { label: "Home", href: "/", isPage: true },
    { label: "Services", href: "/services", isPage: true },
    { label: "How It Works", href: "/how-it-works", isPage: true },
    { label: "FAQ", href: "#faq", isAnchor: true },
  ];

  const handleNavClick = (link: typeof navLinks[0]) => {
    setIsMenuOpen(false);
    
    if (link.isAnchor) {
      if (location.pathname !== "/") {
        navigate("/");
        setTimeout(() => {
          document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" });
        }, 100);
      } else {
        document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  const handleBookDemo = () => {
    const bookDemoSection = document.getElementById("book-demo");
    if (bookDemoSection) {
      bookDemoSection.scrollIntoView({ behavior: "smooth" });
    } else if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => {
        document.getElementById("book-demo")?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="container-custom section-padding !py-4">
        <nav className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <span className="text-primary-foreground font-heading font-bold text-xl">L</span>
            </div>
            <span className="font-heading font-bold text-xl text-foreground">
              LocalFlow <span className="gradient-text">AI</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              link.isPage ? (
                <Link
                  key={link.href}
                  to={link.href}
                  className="text-muted-foreground hover:text-foreground transition-colors duration-300 text-sm font-medium"
                >
                  {link.label}
                </Link>
              ) : (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link)}
                  className="text-muted-foreground hover:text-foreground transition-colors duration-300 text-sm font-medium"
                >
                  {link.label}
                </button>
              )
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button variant="hero" size="lg" onClick={handleBookDemo}>
              Book Free Demo
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-foreground p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-border pt-4 animate-fade-in">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                link.isPage ? (
                  <Link
                    key={link.href}
                    to={link.href}
                    className="text-muted-foreground hover:text-foreground transition-colors duration-300 text-base font-medium"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.label}
                  </Link>
                ) : (
                  <button
                    key={link.href}
                    onClick={() => handleNavClick(link)}
                    className="text-muted-foreground hover:text-foreground transition-colors duration-300 text-base font-medium text-left"
                  >
                    {link.label}
                  </button>
                )
              ))}
              <Button variant="hero" size="lg" className="mt-2" onClick={handleBookDemo}>
                Book Free Demo
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
