import { Building2, Stethoscope, Scissors, Wrench, Briefcase } from "lucide-react";

const WhoItsForSection = () => {
  const industries = [
    {
      icon: Building2,
      title: "Local Service Businesses",
      examples: "Plumbers, electricians, HVAC, cleaning services",
    },
    {
      icon: Stethoscope,
      title: "Medical & Dental Offices",
      examples: "Clinics, dental practices, chiropractors, optometrists",
    },
    {
      icon: Scissors,
      title: "Salons & Barbershops",
      examples: "Hair salons, barbershops, spas, nail studios",
    },
    {
      icon: Wrench,
      title: "Home Services",
      examples: "Contractors, landscapers, pest control, painters",
    },
    {
      icon: Briefcase,
      title: "Professional Services",
      examples: "Law firms, accountants, real estate, consultants",
    },
  ];

  return (
    <section className="relative section-padding">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background" />

      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Industries Grid */}
          <div className="order-2 lg:order-1">
            <div className="grid sm:grid-cols-2 gap-4">
              {industries.map((industry, index) => (
                <div
                  key={index}
                  className="glass rounded-2xl p-6 hover:bg-card/80 transition-all duration-300 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <industry.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-heading font-semibold text-foreground mb-2">
                    {industry.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {industry.examples}
                  </p>
                </div>
              ))}

              {/* CTA Card */}
              <div className="sm:col-span-2 gradient-border rounded-2xl bg-primary/5 p-6 text-center">
                <p className="text-lg font-medium text-foreground mb-2">
                  If your business depends on <span className="gradient-text">calls, bookings, or reviews</span>...
                </p>
                <p className="text-muted-foreground">
                  LocalFlow AI is built for you.
                </p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              Who It's For
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 text-balance">
              Built for{" "}
              <span className="gradient-text">Local Businesses</span>{" "}
              Like Yours
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Whether you're a solo practitioner or managing a team, if phone calls, 
              appointments, and customer reviews drive your business — LocalFlow AI 
              is designed specifically for you.
            </p>
            <p className="text-muted-foreground">
              Our AI solutions work seamlessly across industries, adapting to your 
              unique workflows while maintaining the personal touch your customers expect.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhoItsForSection;
