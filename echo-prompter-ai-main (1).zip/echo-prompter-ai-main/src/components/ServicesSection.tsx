import { Phone, Star, MessageSquare, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const ServicesSection = () => {
  const services = [
    {
      icon: Phone,
      title: "AI Voice Receptionist",
      description: "Never miss a call again. Your AI receptionist handles everything professionally, 24/7.",
      features: [
        "Answers inbound calls 24/7",
        "Books appointments automatically",
        "Handles FAQs instantly",
        "Sends missed-call text messages",
        "Transfers urgent calls if needed",
      ],
      benefit: "Never miss a lead again.",
    },
    {
      icon: Star,
      title: "Review AI System",
      description: "Automate your reputation management and watch your 5-star reviews multiply.",
      features: [
        "Automatically requests reviews via SMS",
        "Follows up with customers",
        "Responds to reviews using AI",
        "Improves Google Maps visibility",
        "Tracks review performance",
      ],
      benefit: "More 5-star reviews, more trust.",
    },
    {
      icon: MessageSquare,
      title: "AI Employee (Chat & SMS)",
      description: "Your tireless AI employee engages leads and books appointments around the clock.",
      features: [
        "Website chat assistant",
        "SMS follow-ups",
        "Lead qualification",
        "Appointment scheduling",
        "Multi-channel support",
      ],
      benefit: "Turn visitors into booked appointments automatically.",
    },
  ];

  return (
    <section id="services" className="relative section-padding">
      {/* Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,hsl(var(--primary)/0.1),transparent_70%)]" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            Our Services
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Everything You Need to{" "}
            <span className="gradient-text">Automate & Grow</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Three powerful AI solutions designed specifically for local businesses. 
            No technical skills required — we handle everything.
          </p>
        </div>

        {/* Service Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group relative"
            >
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/10 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative glass rounded-3xl p-8 h-full flex flex-col hover:bg-card/80 transition-all duration-300">
                {/* Icon */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <service.icon className="w-8 h-8 text-primary-foreground" />
                </div>

                {/* Title */}
                <h3 className="font-heading text-2xl font-bold text-foreground mb-3">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-muted-foreground mb-6">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-3 mb-8 flex-grow">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Benefit Badge */}
                <div className="mt-auto">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    <span className="text-sm font-medium text-primary">{service.benefit}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button variant="hero" size="xl" asChild>
            <a href="/get-started">Get Started Today</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
